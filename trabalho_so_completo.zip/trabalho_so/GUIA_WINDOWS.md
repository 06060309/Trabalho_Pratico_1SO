# 🪟 Guia Completo para Windows - Trabalho Prático 1

Este guia apresenta **3 métodos diferentes** para executar o projeto no Windows, do mais fácil ao mais avançado.

---

## 🎯 Método 1: WSL2 (RECOMENDADO) - Mais Fácil

O **Windows Subsystem for Linux (WSL2)** é a forma mais simples e compatível.

### Passo 1: Instalar WSL2

1. **Abrir PowerShell como Administrador**
   - Pressione `Win + X`
   - Clique em "Windows PowerShell (Admin)" ou "Terminal (Admin)"

2. **Instalar WSL2**
   ```powershell
   wsl --install -d Ubuntu
   ```

3. **Reiniciar o computador** quando solicitado

4. **Configurar Ubuntu**
   - Após reiniciar, o Ubuntu será aberto automaticamente
   - Crie um nome de usuário e senha quando solicitado
   - Aguarde a instalação finalizar

### Passo 2: Preparar o Ambiente Ubuntu

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar ferramentas necessárias
sudo apt install -y build-essential python3 python3-pip

# Verificar instalação
g++ --version
python3 --version
```

### Passo 3: Baixar e Executar o Projeto

```bash
# Navegar para o diretório home
cd ~

# Se você baixou o arquivo no Windows, copie para WSL:
# (substitua USERNAME pelo seu usuário do Windows)
cp /mnt/c/Users/USERNAME/Downloads/trabalho_so_completo.tar.gz .

# Extrair projeto
tar -xzf trabalho_so_completo.tar.gz
cd trabalho_so

# Executar instalação automática
./instalar.sh

# Executar todos os experimentos
make experimentos
```

### Passo 4: Acessar Resultados

```bash
# Ver gráficos (abrirá no Windows)
explorer.exe .

# Ou copiar para Windows
cp *.png *.md *.csv /mnt/c/Users/USERNAME/Desktop/
```

---

## 🛠️ Método 2: MinGW-w64 - Nativo Windows

Para quem prefere executar diretamente no Windows sem virtualização.

### Passo 1: Instalar MinGW-w64

1. **Baixar MSYS2**
   - Acesse: https://www.msys2.org/
   - Baixe o instalador para Windows
   - Execute como administrador

2. **Instalar ferramentas**
   ```bash
   # No terminal MSYS2
   pacman -S mingw-w64-x86_64-gcc
   pacman -S mingw-w64-x86_64-python
   pacman -S mingw-w64-x86_64-python-pip
   pacman -S make
   ```

3. **Adicionar ao PATH**
   - Adicione `C:\msys64\mingw64\bin` ao PATH do Windows
   - Painel de Controle → Sistema → Configurações Avançadas → Variáveis de Ambiente

### Passo 2: Instalar Python Libraries

```bash
# No terminal MSYS2 ou CMD
pip install pandas matplotlib seaborn numpy
```

### Passo 3: Adaptar Código para Windows

Crie um arquivo `compilar_windows.bat`:

```batch
@echo off
echo Compilando programas para Windows...

g++ -o gerador_matrizes.exe gerador_matrizes.cpp -std=c++11
g++ -o multiplicacao_sequencial.exe multiplicacao_sequencial.cpp -std=c++11 -O2
g++ -o multiplicacao_threads.exe multiplicacao_threads.cpp -std=c++11 -pthread -O2
g++ -o multiplicacao_processos.exe multiplicacao_processos.cpp -std=c++11 -O2

echo Compilacao concluida!
pause
```

### Passo 4: Executar

```batch
# Compilar
compilar_windows.bat

# Testar
gerador_matrizes.exe 100
multiplicacao_sequencial.exe 100
multiplicacao_threads.exe 100 4
multiplicacao_processos.exe 100 4
```

---

## 🐳 Método 3: Docker - Isolado e Portável

Para um ambiente completamente isolado e reproduzível.

### Passo 1: Instalar Docker Desktop

1. **Baixar Docker Desktop**
   - Acesse: https://www.docker.com/products/docker-desktop
   - Baixe e instale para Windows
   - Reinicie quando solicitado

2. **Verificar instalação**
   ```powershell
   docker --version
   ```

### Passo 2: Criar Dockerfile

Crie um arquivo `Dockerfile`:

```dockerfile
FROM ubuntu:22.04

# Instalar dependências
RUN apt-get update && apt-get install -y \
    build-essential \
    python3 \
    python3-pip \
    && rm -rf /var/lib/apt/lists/*

# Instalar bibliotecas Python
RUN pip3 install pandas matplotlib seaborn numpy

# Criar diretório de trabalho
WORKDIR /trabalho

# Copiar arquivos do projeto
COPY . .

# Compilar programas
RUN g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11 && \
    g++ -o multiplicacao_sequencial multiplicacao_sequencial.cpp -std=c++11 -O2 && \
    g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2 && \
    g++ -o multiplicacao_processos multiplicacao_processos.cpp -std=c++11 -O2

# Tornar scripts executáveis
RUN chmod +x *.sh

CMD ["/bin/bash"]
```

### Passo 3: Executar com Docker

```powershell
# Construir imagem
docker build -t trabalho-so .

# Executar container
docker run -it --rm -v ${PWD}:/output trabalho-so

# Dentro do container:
./verificar_corretude.sh
make experimentos

# Copiar resultados para Windows
cp *.png *.csv *.md /output/
```

---

## 🎮 Scripts Específicos para Windows

### Script PowerShell para Automação

Crie `executar.ps1`:

```powershell
# Verificar se WSL está instalado
if (Get-Command wsl -ErrorAction SilentlyContinue) {
    Write-Host "Executando via WSL..." -ForegroundColor Green
    
    # Copiar arquivo para WSL se necessário
    if (Test-Path "trabalho_so_completo.tar.gz") {
        wsl cp trabalho_so_completo.tar.gz ~/
    }
    
    # Executar no WSL
    wsl bash -c "cd ~ && tar -xzf trabalho_so_completo.tar.gz && cd trabalho_so && ./instalar.sh && make experimentos"
    
    # Copiar resultados de volta
    wsl cp ~/trabalho_so/*.png ~/trabalho_so/*.csv ~/trabalho_so/*.md ./
    
    Write-Host "Resultados copiados para o diretório atual!" -ForegroundColor Green
} else {
    Write-Host "WSL não encontrado. Instale o WSL2 primeiro." -ForegroundColor Red
}
```

### Script Batch Simples

Crie `executar.bat`:

```batch
@echo off
echo Verificando WSL...

wsl --version >nul 2>&1
if %errorlevel% neq 0 (
    echo WSL nao encontrado. Instalando...
    wsl --install -d Ubuntu
    echo Reinicie o computador e execute este script novamente.
    pause
    exit
)

echo Executando projeto no WSL...
wsl bash -c "cd ~ && tar -xzf trabalho_so_completo.tar.gz && cd trabalho_so && ./instalar.sh && make experimentos"

echo Copiando resultados...
wsl cp ~/trabalho_so/*.png .
wsl cp ~/trabalho_so/*.csv .
wsl cp ~/trabalho_so/*.md .

echo Concluido! Verifique os arquivos no diretorio atual.
pause
```

---

## 🔧 Configurações Específicas do Windows

### Configurar WSL2 para Melhor Performance

1. **Criar arquivo `.wslconfig`** em `C:\Users\USERNAME\`:
   ```ini
   [wsl2]
   memory=4GB
   processors=4
   swap=2GB
   ```

2. **Reiniciar WSL**:
   ```powershell
   wsl --shutdown
   wsl
   ```

### Acessar Arquivos entre Windows e WSL

```bash
# Do WSL para Windows
cp arquivo.txt /mnt/c/Users/USERNAME/Desktop/

# Do Windows para WSL (no PowerShell)
copy arquivo.txt \\wsl$\Ubuntu\home\username\
```

---

## 📊 Visualizar Resultados no Windows

### Opção 1: Navegador
```bash
# No WSL, abrir arquivo no navegador Windows
explorer.exe relatorio.md
```

### Opção 2: VS Code
```bash
# Instalar VS Code com extensão WSL
code .
```

### Opção 3: Copiar para Windows
```bash
# Copiar todos os resultados
cp *.png *.md *.csv /mnt/c/Users/USERNAME/Desktop/resultados/
```

---

## 🚨 Solução de Problemas Windows

### Problema: "WSL não está habilitado"
```powershell
# Habilitar WSL (como Admin)
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart

# Reiniciar e executar:
wsl --set-default-version 2
```

### Problema: "Virtualization not enabled"
1. Reiniciar o PC
2. Entrar na BIOS/UEFI (F2, F12, Del durante boot)
3. Habilitar "Intel VT-x" ou "AMD-V"
4. Salvar e reiniciar

### Problema: "Docker não inicia"
1. Verificar se Hyper-V está habilitado
2. Verificar se WSL2 está instalado
3. Reiniciar Docker Desktop

### Problema: "Permission denied" no WSL
```bash
chmod +x *.sh
sudo chown -R $USER:$USER .
```

---

## 🎯 Resumo dos Métodos

| Método | Dificuldade | Tempo Setup | Compatibilidade | Recomendado |
|--------|-------------|-------------|-----------------|-------------|
| **WSL2** | ⭐⭐ | 10-15 min | 100% | ✅ **SIM** |
| **MinGW** | ⭐⭐⭐ | 20-30 min | 90% | Para usuários avançados |
| **Docker** | ⭐⭐⭐⭐ | 15-20 min | 100% | Para isolamento |

---

## 🏁 Execução Rápida (WSL2)

```powershell
# 1. Instalar WSL2 (uma vez só)
wsl --install -d Ubuntu

# 2. Após reiniciar, executar:
wsl bash -c "sudo apt update && sudo apt install -y build-essential python3 python3-pip"

# 3. Copiar e executar projeto:
wsl cp trabalho_so_completo.tar.gz ~/
wsl bash -c "cd ~ && tar -xzf trabalho_so_completo.tar.gz && cd trabalho_so && ./instalar.sh && make experimentos"

# 4. Copiar resultados:
wsl cp ~/trabalho_so/*.png ~/trabalho_so/*.md .
```

**Tempo total: ~15-20 minutos (incluindo downloads)**

---

## 💡 Dicas Importantes

1. **Use WSL2** - É a opção mais fácil e compatível
2. **Antivírus** - Adicione exceção para pasta do projeto
3. **Firewall** - Pode bloquear compilação, desabilite temporariamente
4. **Espaço** - Reserve pelo menos 2GB livres
5. **Memória** - Feche outros programas durante execução

**Boa sorte com o projeto! 🚀**
