# ⚡ Comandos Rápidos - Trabalho Prático 1

## 🚀 Instalação em Uma Linha

```bash
# Baixar, extrair e instalar automaticamente
tar -xzf trabalho_so_completo.tar.gz && cd trabalho_so && ./instalar.sh
```

## 🎯 Execução Completa (Automática)

```bash
# Executar todos os experimentos e gerar relatórios
make experimentos
```

## 🧪 Testes Individuais

### Teste Básico (30 segundos)
```bash
./verificar_corretude.sh
```

### Teste com Matriz Pequena (1 minuto)
```bash
./gerador_matrizes 100
./multiplicacao_sequencial 100
./multiplicacao_threads 100 4
./multiplicacao_processos 100 4
```

### Experimento E1 Simplificado (5 minutos)
```bash
# Testar apenas algumas dimensões
for size in 100 200 400; do
    ./gerador_matrizes $size
    echo "Sequencial $size: $(./multiplicacao_sequencial $size | grep 'Tempo de execução:' | awk '{print $4}') ms"
    echo "Threads $size: $(./multiplicacao_threads $size 4 | grep 'Tempo de execução:' | awk '{print $4}') ms"
    echo "Processos $size: $(./multiplicacao_processos $size 4 | grep 'Tempo de execução:' | awk '{print $4}') ms"
    echo "---"
done
```

### Experimento E2 Simplificado (3 minutos)
```bash
# Testar diferentes valores de P
./gerador_matrizes 200
for p in 1 2 4 8; do
    echo "P=$p Threads: $(./multiplicacao_threads 200 $p | grep 'Tempo de execução:' | awk '{print $4}') ms"
    echo "P=$p Processos: $(./multiplicacao_processos 200 $p | grep 'Tempo de execução:' | awk '{print $4}') ms"
done
```

## 🛠️ Compilação Manual

```bash
# Compilar tudo
g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11
g++ -o multiplicacao_sequencial multiplicacao_sequencial.cpp -std=c++11 -O2
g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2
g++ -o multiplicacao_processos multiplicacao_processos.cpp -std=c++11 -O2
```

## 📊 Gerar Apenas os Gráficos

```bash
# Se você já tem os CSVs
python3 analisar_resultados.py
```

## 🧹 Limpeza

```bash
# Limpar arquivos temporários
make clean

# Limpar tudo (incluindo resultados)
make distclean

# Limpar manualmente
rm -f gerador_matrizes multiplicacao_* matriz_*.txt resultado_*.txt *.csv *.png
```

## 🔍 Verificações Rápidas

```bash
# Verificar se compilou
ls -la gerador_matrizes multiplicacao_*

# Verificar dependências Python
python3 -c "import pandas, matplotlib, seaborn, numpy; print('OK')"

# Ver informações do sistema
nproc  # Número de núcleos
free -h  # Memória disponível
df -h .  # Espaço em disco
```

## 📈 Monitoramento Durante Execução

```bash
# Em outro terminal, monitorar recursos
htop

# Ou usar top
top

# Monitorar uso de CPU por processo
watch -n 1 'ps aux | grep multiplicacao'
```

## 🎮 Comandos de Desenvolvimento

```bash
# Compilar com debug
g++ -g -o programa programa.cpp -std=c++11

# Executar com profiling
time ./multiplicacao_sequencial 400

# Verificar vazamentos de memória (se tiver valgrind)
valgrind --leak-check=full ./multiplicacao_processos 100 2
```

## 🚨 Solução de Problemas Rápida

```bash
# Problema: Permission denied
chmod +x *.sh

# Problema: g++ not found
sudo apt install build-essential  # Ubuntu/Debian
sudo yum groupinstall "Development Tools"  # CentOS/RHEL

# Problema: python3 not found
sudo apt install python3 python3-pip  # Ubuntu/Debian

# Problema: ModuleNotFoundError
pip3 install --user pandas matplotlib seaborn numpy

# Problema: Compilation error
# Verificar se todos os arquivos .cpp estão presentes
ls -la *.cpp
```

## 📱 Comandos para Diferentes Sistemas

### Ubuntu/Debian
```bash
sudo apt update && sudo apt install -y build-essential python3 python3-pip
pip3 install pandas matplotlib seaborn numpy
```

### CentOS/RHEL
```bash
sudo yum groupinstall -y "Development Tools"
sudo yum install -y python3 python3-pip
pip3 install pandas matplotlib seaborn numpy
```

### macOS
```bash
xcode-select --install
brew install python3
pip3 install pandas matplotlib seaborn numpy
```

### Windows (WSL2)
```bash
# No PowerShell (como Admin):
wsl --install -d Ubuntu

# No Ubuntu WSL:
sudo apt update && sudo apt install -y build-essential python3 python3-pip
pip3 install pandas matplotlib seaborn numpy
```

## 🏃‍♂️ Execução Super Rápida (2 minutos)

```bash
# Para demonstração rápida
./instalar.sh && \
./verificar_corretude.sh && \
./gerador_matrizes 200 && \
echo "Seq: $(./multiplicacao_sequencial 200 | grep 'Tempo' | awk '{print $4}')ms" && \
echo "Thr: $(./multiplicacao_threads 200 4 | grep 'Tempo' | awk '{print $4}')ms" && \
echo "Proc: $(./multiplicacao_processos 200 4 | grep 'Tempo' | awk '{print $4}')ms"
```
