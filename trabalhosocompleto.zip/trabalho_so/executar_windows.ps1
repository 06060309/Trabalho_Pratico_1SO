# Script PowerShell para Executar Trabalho Prático 1 no Windows
# Trabalho de Sistemas Operacionais - Multiplicação de Matrizes

param(
    [switch]$InstalarWSL,
    [switch]$ApenasExecutar,
    [string]$ArquivoTar = "trabalho_so_completo.tar.gz"
)

# Cores para output
$ErrorColor = "Red"
$SuccessColor = "Green"
$InfoColor = "Cyan"
$WarningColor = "Yellow"

function Write-ColorOutput {
    param([string]$Message, [string]$Color = "White")
    Write-Host $Message -ForegroundColor $Color
}

function Test-WSLInstalled {
    try {
        $wslVersion = wsl --version 2>$null
        return $true
    }
    catch {
        return $false
    }
}

function Test-WSLRunning {
    try {
        $result = wsl bash -c "echo 'test'" 2>$null
        return $result -eq "test"
    }
    catch {
        return $false
    }
}

function Install-WSL {
    Write-ColorOutput "🔧 Instalando WSL2..." $InfoColor
    
    try {
        # Verificar se está executando como administrador
        $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
        $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        
        if (-not $isAdmin) {
            Write-ColorOutput "❌ Este script precisa ser executado como Administrador para instalar WSL." $ErrorColor
            Write-ColorOutput "💡 Clique com botão direito no PowerShell e selecione 'Executar como Administrador'" $WarningColor
            return $false
        }
        
        # Instalar WSL
        Write-ColorOutput "Instalando WSL2 com Ubuntu..." $InfoColor
        wsl --install -d Ubuntu
        
        Write-ColorOutput "✅ WSL2 instalado com sucesso!" $SuccessColor
        Write-ColorOutput "🔄 REINICIE o computador e execute este script novamente." $WarningColor
        return $true
    }
    catch {
        Write-ColorOutput "❌ Erro ao instalar WSL: $($_.Exception.Message)" $ErrorColor
        return $false
    }
}

function Setup-WSLEnvironment {
    Write-ColorOutput "🛠️ Configurando ambiente WSL..." $InfoColor
    
    # Atualizar sistema
    Write-ColorOutput "Atualizando sistema Ubuntu..." $InfoColor
    wsl bash -c "sudo apt update && sudo apt upgrade -y"
    
    # Instalar ferramentas
    Write-ColorOutput "Instalando ferramentas de desenvolvimento..." $InfoColor
    wsl bash -c "sudo apt install -y build-essential python3 python3-pip"
    
    # Verificar instalação
    $gccVersion = wsl bash -c "g++ --version | head -1"
    $pythonVersion = wsl bash -c "python3 --version"
    
    Write-ColorOutput "✅ g++: $gccVersion" $SuccessColor
    Write-ColorOutput "✅ Python: $pythonVersion" $SuccessColor
    
    return $true
}

function Copy-ProjectToWSL {
    param([string]$TarFile)
    
    Write-ColorOutput "📁 Copiando projeto para WSL..." $InfoColor
    
    if (-not (Test-Path $TarFile)) {
        Write-ColorOutput "❌ Arquivo $TarFile não encontrado!" $ErrorColor
        Write-ColorOutput "💡 Certifique-se de que o arquivo está no diretório atual." $WarningColor
        return $false
    }
    
    # Copiar arquivo para WSL
    $windowsPath = (Resolve-Path $TarFile).Path
    wsl cp "$windowsPath" ~/
    
    Write-ColorOutput "✅ Arquivo copiado para WSL" $SuccessColor
    return $true
}

function Execute-Project {
    Write-ColorOutput "🚀 Executando projeto..." $InfoColor
    
    # Extrair e executar
    Write-ColorOutput "Extraindo projeto..." $InfoColor
    wsl bash -c "cd ~ && tar -xzf trabalho_so_completo.tar.gz"
    
    Write-ColorOutput "Executando instalação automática..." $InfoColor
    wsl bash -c "cd ~/trabalho_so && ./instalar.sh"
    
    Write-ColorOutput "Executando experimentos..." $InfoColor
    wsl bash -c "cd ~/trabalho_so && make experimentos"
    
    Write-ColorOutput "✅ Experimentos concluídos!" $SuccessColor
    return $true
}

function Copy-ResultsToWindows {
    Write-ColorOutput "📋 Copiando resultados para Windows..." $InfoColor
    
    # Criar diretório de resultados
    $resultsDir = "resultados_trabalho_so"
    if (-not (Test-Path $resultsDir)) {
        New-Item -ItemType Directory -Path $resultsDir | Out-Null
    }
    
    # Copiar arquivos
    wsl cp ~/trabalho_so/*.png ./$resultsDir/ 2>$null
    wsl cp ~/trabalho_so/*.csv ./$resultsDir/ 2>$null
    wsl cp ~/trabalho_so/*.md ./$resultsDir/ 2>$null
    wsl cp ~/trabalho_so/Makefile ./$resultsDir/ 2>$null
    
    Write-ColorOutput "✅ Resultados copiados para: $resultsDir" $SuccessColor
    
    # Abrir pasta de resultados
    Start-Process explorer.exe -ArgumentList $resultsDir
    
    return $true
}

function Show-Results {
    Write-ColorOutput "`n🎉 PROJETO EXECUTADO COM SUCESSO!" $SuccessColor
    Write-ColorOutput "=================================" $SuccessColor
    Write-ColorOutput ""
    Write-ColorOutput "📊 Arquivos gerados:" $InfoColor
    Write-ColorOutput "   • Gráficos: grafico_experimento_e1.png, grafico_experimento_e2.png" 
    Write-ColorOutput "   • Dados: resultados_e1.csv, resultados_e2.csv"
    Write-ColorOutput "   • Relatório: relatorio.md"
    Write-ColorOutput "   • Instruções: README.md"
    Write-ColorOutput ""
    Write-ColorOutput "🎯 Principais resultados:" $InfoColor
    Write-ColorOutput "   • Speedup máximo: ~4.4x"
    Write-ColorOutput "   • P ideal: 4 threads/processos"
    Write-ColorOutput "   • Melhor eficiência: P=2"
    Write-ColorOutput ""
    Write-ColorOutput "📁 Todos os arquivos estão em: resultados_trabalho_so/" $WarningColor
}

# Função principal
function Main {
    Write-ColorOutput "🚀 TRABALHO PRÁTICO 1 - SISTEMAS OPERACIONAIS" $InfoColor
    Write-ColorOutput "=============================================" $InfoColor
    Write-ColorOutput "Multiplicação de Matrizes: Sequencial vs Paralelo" $InfoColor
    Write-ColorOutput ""
    
    # Verificar se WSL está instalado
    if (-not (Test-WSLInstalled)) {
        Write-ColorOutput "❌ WSL não está instalado." $ErrorColor
        
        if ($InstalarWSL) {
            if (Install-WSL) {
                Write-ColorOutput "🔄 Reinicie o computador e execute novamente com -ApenasExecutar" $WarningColor
                return
            } else {
                return
            }
        } else {
            Write-ColorOutput "💡 Execute com -InstalarWSL para instalar automaticamente:" $WarningColor
            Write-ColorOutput "   .\executar_windows.ps1 -InstalarWSL" $WarningColor
            return
        }
    }
    
    # Verificar se WSL está funcionando
    if (-not (Test-WSLRunning)) {
        Write-ColorOutput "❌ WSL não está funcionando corretamente." $ErrorColor
        Write-ColorOutput "💡 Tente reiniciar o WSL: wsl --shutdown && wsl" $WarningColor
        return
    }
    
    Write-ColorOutput "✅ WSL detectado e funcionando!" $SuccessColor
    
    # Configurar ambiente se necessário
    if (-not $ApenasExecutar) {
        if (-not (Setup-WSLEnvironment)) {
            Write-ColorOutput "❌ Erro ao configurar ambiente WSL" $ErrorColor
            return
        }
    }
    
    # Copiar projeto
    if (-not (Copy-ProjectToWSL -TarFile $ArquivoTar)) {
        return
    }
    
    # Executar projeto
    if (-not (Execute-Project)) {
        Write-ColorOutput "❌ Erro ao executar projeto" $ErrorColor
        return
    }
    
    # Copiar resultados
    if (-not (Copy-ResultsToWindows)) {
        Write-ColorOutput "❌ Erro ao copiar resultados" $ErrorColor
        return
    }
    
    # Mostrar resultados
    Show-Results
}

# Executar função principal
try {
    Main
}
catch {
    Write-ColorOutput "❌ Erro inesperado: $($_.Exception.Message)" $ErrorColor
    Write-ColorOutput "💡 Tente executar os comandos manualmente ou consulte o GUIA_WINDOWS.md" $WarningColor
}

Write-ColorOutput "`nPressione qualquer tecla para continuar..." $InfoColor
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
