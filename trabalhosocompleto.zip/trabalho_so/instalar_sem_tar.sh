#!/bin/bash

# Script de Instalação sem arquivo TAR
# Trabalho Prático 1 - Sistemas Operacionais

echo "🚀 INSTALAÇÃO DO TRABALHO PRÁTICO 1"
echo "===================================="
echo "Multiplicação de Matrizes: Sequencial vs Paralelo"
echo

# Detectar sistema operacional
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
else
    OS="unknown"
fi

echo "Sistema detectado: $OS"
echo

# Função para verificar se comando existe
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Verificar e instalar dependências
echo "📋 Verificando dependências..."

# Verificar g++
if command_exists g++; then
    echo "✅ g++ já instalado: $(g++ --version | head -1)"
else
    echo "❌ g++ não encontrado. Instalando..."
    if [[ "$OS" == "linux" ]]; then
        if command_exists apt; then
            sudo apt update && sudo apt install -y build-essential
        elif command_exists yum; then
            sudo yum groupinstall -y "Development Tools"
        elif command_exists dnf; then
            sudo dnf groupinstall -y "Development Tools"
        else
            echo "❌ Gerenciador de pacotes não suportado. Instale g++ manualmente."
            exit 1
        fi
    elif [[ "$OS" == "macos" ]]; then
        echo "Execute: xcode-select --install"
        exit 1
    fi
fi

# Verificar Python3
if command_exists python3; then
    echo "✅ Python3 já instalado: $(python3 --version)"
else
    echo "❌ Python3 não encontrado. Instalando..."
    if [[ "$OS" == "linux" ]]; then
        if command_exists apt; then
            sudo apt install -y python3 python3-pip
        elif command_exists yum; then
            sudo yum install -y python3 python3-pip
        elif command_exists dnf; then
            sudo dnf install -y python3 python3-pip
        fi
    elif [[ "$OS" == "macos" ]]; then
        if command_exists brew; then
            brew install python3
        else
            echo "❌ Homebrew não encontrado. Instale Python3 manualmente."
            exit 1
        fi
    fi
fi

# Verificar pip3
if command_exists pip3; then
    echo "✅ pip3 já instalado"
else
    echo "❌ pip3 não encontrado"
    exit 1
fi

echo

# Instalar bibliotecas Python
echo "🐍 Instalando bibliotecas Python..."
pip3 install --user pandas matplotlib seaborn numpy

# Verificar instalação das bibliotecas
echo "🔍 Verificando bibliotecas Python..."
python3 -c "import pandas, matplotlib, seaborn, numpy; print('✅ Todas as bibliotecas Python instaladas!')" 2>/dev/null || {
    echo "❌ Erro ao instalar bibliotecas Python. Tente manualmente:"
    echo "pip3 install pandas matplotlib seaborn numpy"
    exit 1
}

echo

# Verificar se os arquivos fonte existem
echo "🔍 Verificando arquivos do projeto..."
arquivos_fonte=("gerador_matrizes.cpp" "multiplicacao_sequencial.cpp" "multiplicacao_threads.cpp" "multiplicacao_processos.cpp")
arquivos_faltando=()

for arquivo in "${arquivos_fonte[@]}"; do
    if [[ ! -f "$arquivo" ]]; then
        arquivos_faltando+=("$arquivo")
    fi
done

if [ ${#arquivos_faltando[@]} -gt 0 ]; then
    echo "❌ Arquivos não encontrados:"
    for arquivo in "${arquivos_faltando[@]}"; do
        echo "   - $arquivo"
    done
    echo
    echo "💡 Certifique-se de estar no diretório correto do projeto."
    echo "💡 Ou baixe os arquivos individualmente dos anexos da conversa."
    exit 1
fi

echo "✅ Todos os arquivos fonte encontrados!"

# Compilar programas
echo
echo "🛠️  Compilando programas..."

echo "Compilando gerador_matrizes..."
g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11 || {
    echo "❌ Erro ao compilar gerador_matrizes"
    exit 1
}

echo "Compilando multiplicacao_sequencial..."
g++ -o multiplicacao_sequencial multiplicacao_sequencial.cpp -std=c++11 -O2 || {
    echo "❌ Erro ao compilar multiplicacao_sequencial"
    exit 1
}

echo "Compilando multiplicacao_threads..."
g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2 || {
    echo "❌ Erro ao compilar multiplicacao_threads"
    exit 1
}

echo "Compilando multiplicacao_processos..."
g++ -o multiplicacao_processos multiplicacao_processos.cpp -std=c++11 -O2 || {
    echo "❌ Erro ao compilar multiplicacao_processos"
    exit 1
}

echo "✅ Todos os programas compilados com sucesso!"
echo

# Tornar scripts executáveis
echo "🔧 Configurando permissões dos scripts..."
chmod +x *.sh 2>/dev/null
echo "✅ Permissões configuradas!"
echo

# Teste rápido
echo "🧪 Executando teste rápido..."
echo "Gerando matriz 10x10..."
./gerador_matrizes 10 >/dev/null 2>&1

echo "Testando multiplicação sequencial..."
./multiplicacao_sequencial 10 >/dev/null 2>&1

echo "Testando multiplicação com threads..."
./multiplicacao_threads 10 2 >/dev/null 2>&1

echo "Testando multiplicação com processos..."
./multiplicacao_processos 10 2 >/dev/null 2>&1

echo "✅ Teste rápido concluído com sucesso!"
echo

# Informações finais
echo "🎉 INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "===================================="
echo
echo "📁 Arquivos disponíveis:"
echo "   - gerador_matrizes (executável)"
echo "   - multiplicacao_sequencial (executável)"
echo "   - multiplicacao_threads (executável)"
echo "   - multiplicacao_processos (executável)"
echo "   - Scripts de experimentos (*.sh)"
echo "   - Script de análise (analisar_resultados.py)"
echo
echo "🚀 Próximos passos:"
echo "   1. Execute: ./verificar_corretude.sh"
echo "   2. Execute: ./experimento_e1.sh"
echo "   3. Execute: ./experimento_e2_rapido.sh"
echo "   4. Execute: python3 analisar_resultados.py"
echo
echo "💡 Dicas:"
echo "   - Use 'make help' para ver todas as opções (se tiver Makefile)"
echo "   - Consulte README.md para instruções detalhadas"
echo
echo "✨ Instalação concluída! Bom trabalho!"
