# 🚀 Guia Passo a Passo - Trabalho Prático 1

Este guia detalha como configurar e executar o projeto de multiplicação de matrizes em sua máquina.

---

## 📋 Pré-requisitos

### Sistema Operacional
- **Linux** (Ubuntu, Debian, CentOS, etc.) - **RECOMENDADO**
- **macOS** (com Xcode Command Line Tools)
- **Windows** (com WSL2 ou MinGW)

### Software Necessário
- Compilador C++ (g++ ou clang++)
- Python 3.x
- Git (opcional, para clonar repositórios)

---

## 🔧 Passo 1: Preparar o Ambiente

### No Ubuntu/Debian:
```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar compilador C++ e ferramentas
sudo apt install -y build-essential

# Instalar Python e pip
sudo apt install -y python3 python3-pip

# Verificar instalações
g++ --version
python3 --version
```

### No CentOS/RHEL/Fedora:
```bash
# CentOS/RHEL
sudo yum groupinstall -y "Development Tools"
sudo yum install -y python3 python3-pip

# Fedora
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y python3 python3-pip
```

### No macOS:
```bash
# Instalar Xcode Command Line Tools
xcode-select --install

# Instalar Homebrew (se não tiver)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Python
brew install python3
```

### No Windows (WSL2):
```bash
# Abrir PowerShell como Administrador e instalar WSL2
wsl --install -d Ubuntu

# Após reiniciar, abrir Ubuntu e executar:
sudo apt update && sudo apt upgrade -y
sudo apt install -y build-essential python3 python3-pip
```

---

## 📦 Passo 2: Baixar e Extrair o Projeto

### Opção A: Download do arquivo compactado
1. Baixe o arquivo `trabalho_so_completo.tar.gz`
2. Extraia em um diretório de sua escolha:

```bash
# Criar diretório para o projeto
mkdir -p ~/projetos
cd ~/projetos

# Extrair arquivo (substitua pelo caminho correto)
tar -xzf ~/Downloads/trabalho_so_completo.tar.gz

# Entrar no diretório
cd trabalho_so
```

### Opção B: Criar manualmente
Se preferir, crie os arquivos manualmente copiando o conteúdo dos arquivos fornecidos.

---

## 🐍 Passo 3: Instalar Dependências Python

```bash
# Instalar bibliotecas necessárias
pip3 install pandas matplotlib seaborn numpy

# Verificar instalação
python3 -c "import pandas, matplotlib, seaborn, numpy; print('Todas as bibliotecas instaladas com sucesso!')"
```

**Se houver erro de permissão, use:**
```bash
pip3 install --user pandas matplotlib seaborn numpy
```

---

## 🛠️ Passo 4: Compilar o Projeto

```bash
# Entrar no diretório do projeto
cd ~/projetos/trabalho_so

# Compilar todos os programas
make all

# OU compilar manualmente:
g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11
g++ -o multiplicacao_sequencial multiplicacao_sequencial.cpp -std=c++11 -O2
g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2
g++ -o multiplicacao_processos multiplicacao_processos.cpp -std=c++11 -O2
```

**Verificar se compilou corretamente:**
```bash
ls -la gerador_matrizes multiplicacao_*
```

Você deve ver 4 arquivos executáveis.

---

## ✅ Passo 5: Teste Rápido

```bash
# Teste de corretude (verifica se todos os programas funcionam)
./verificar_corretude.sh

# OU teste manual:
./gerador_matrizes 10
./multiplicacao_sequencial 10
./multiplicacao_threads 10 2
./multiplicacao_processos 10 2
```

**Saída esperada:**
```
=== VERIFICAÇÃO DE CORRETUDE ===
...
✓ Sequencial e Threads: IDÊNTICOS
✓ Sequencial e Processos: IDÊNTICOS
✓ Threads e Processos: IDÊNTICOS
=== VERIFICAÇÃO CONCLUÍDA ===
```

---

## 🧪 Passo 6: Executar Experimentos

### Experimento E1 (Sequencial vs Paralelo)
```bash
# Execução automática (pode demorar alguns minutos)
./experimento_e1.sh

# OU execução manual para teste rápido:
./gerador_matrizes 100
./multiplicacao_sequencial 100
./multiplicacao_threads 100 4
./multiplicacao_processos 100 4
```

### Experimento E2 (Impacto do número de P)
```bash
# Execução automática (versão rápida)
./experimento_e2_rapido.sh

# OU teste manual:
./gerador_matrizes 200
./multiplicacao_threads 200 1
./multiplicacao_threads 200 2
./multiplicacao_threads 200 4
```

---

## 📊 Passo 7: Gerar Análises e Gráficos

```bash
# Gerar gráficos e análises
python3 analisar_resultados.py

# Verificar arquivos gerados
ls -la *.png *.csv
```

**Arquivos esperados:**
- `grafico_experimento_e1.png`
- `grafico_experimento_e2.png`
- `resultados_e1.csv`
- `resultados_e2.csv`

---

## 🎯 Passo 8: Executar Tudo Automaticamente

```bash
# Compilar, testar e executar todos os experimentos
make experimentos

# OU passo a passo:
make clean      # Limpar arquivos antigos
make all        # Compilar tudo
make test       # Testar corretude
./experimento_e1.sh
./experimento_e2_rapido.sh
python3 analisar_resultados.py
```

---

## 🔍 Verificação de Problemas

### Problema: "g++: command not found"
```bash
# Ubuntu/Debian
sudo apt install build-essential

# CentOS/RHEL
sudo yum groupinstall "Development Tools"

# macOS
xcode-select --install
```

### Problema: "python3: command not found"
```bash
# Ubuntu/Debian
sudo apt install python3 python3-pip

# CentOS/RHEL
sudo yum install python3 python3-pip

# macOS
brew install python3
```

### Problema: "ModuleNotFoundError: No module named 'pandas'"
```bash
pip3 install pandas matplotlib seaborn numpy
# Se não funcionar:
pip3 install --user pandas matplotlib seaborn numpy
```

### Problema: "Permission denied" ao executar scripts
```bash
chmod +x *.sh
```

### Problema: Compilação falha com erro de thread
```bash
# Certifique-se de usar a flag -pthread
g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2
```

---

## 📈 Interpretando os Resultados

### Tempos de Execução
- **ms**: milissegundos
- **Sequencial**: Tempo da versão sem paralelismo
- **Threads/Processos**: Tempo das versões paralelas

### Speedup
```
Speedup = Tempo_Sequencial / Tempo_Paralelo
```
- **1.0x**: Sem melhoria
- **2.0x**: 2x mais rápido
- **4.0x**: 4x mais rápido (ideal para 4 núcleos)

### Eficiência
```
Eficiência = Speedup / Número_de_P
```
- **1.0**: Eficiência perfeita (100%)
- **0.5**: 50% de eficiência

---

## 🎮 Comandos Úteis

```bash
# Ver ajuda do Makefile
make help

# Limpar arquivos temporários
make clean

# Limpar tudo (incluindo resultados)
make distclean

# Compilar apenas um programa
make gerador_matrizes

# Testar com matriz específica
./gerador_matrizes 500
./multiplicacao_sequencial 500
./multiplicacao_threads 500 8
```

---

## 📞 Solução de Problemas

### Se algo não funcionar:

1. **Verifique os pré-requisitos** (g++, python3)
2. **Confira as permissões** dos scripts (`chmod +x *.sh`)
3. **Teste compilação manual** de cada programa
4. **Execute passo a passo** em vez dos scripts automáticos
5. **Verifique o espaço em disco** (matrizes grandes ocupam espaço)

### Para depuração:
```bash
# Compilar com informações de debug
g++ -g -o programa programa.cpp -std=c++11

# Executar com verbose
./experimento_e1.sh 2>&1 | tee log.txt
```

---

## ✨ Dicas de Performance

1. **Feche outros programas** durante os testes
2. **Use SSD** se possível (I/O mais rápido)
3. **Monitore recursos** com `htop` ou `top`
4. **Ajuste P** para o número de núcleos da sua CPU
5. **Para testes rápidos**, use matrizes menores (100x100, 200x200)

---

## 🏁 Resultado Final

Após seguir todos os passos, você terá:

- ✅ 4 programas compilados e funcionando
- ✅ Dados de desempenho coletados
- ✅ Gráficos comparativos gerados
- ✅ Relatório completo com análises
- ✅ Compreensão dos conceitos de paralelismo

**Tempo estimado total: 15-30 minutos**
