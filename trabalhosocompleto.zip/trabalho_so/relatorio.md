# Relatório do Trabalho Prático 1: Análise de Desempenho da Multiplicação de Matrizes

**Autor:** Manus AI
**Data:** 29 de Setembro de 2025

---

## 1. Introdução

Este relatório apresenta a implementação e a análise de desempenho de algoritmos de multiplicação de matrizes, conforme solicitado no Trabalho Prático 1 da disciplina de Sistemas Operacionais. O objetivo principal é comparar a eficiência de três abordagens distintas: uma implementação **sequencial**, uma **paralela utilizando threads** e outra **paralela utilizando processos**.

A multiplicação de matrizes é uma operação computacionalmente intensiva, com complexidade de tempo O(n³), o que a torna um excelente caso de estudo para avaliar os ganhos de desempenho obtidos com técnicas de paralelização. Este trabalho explora como a divisão de tarefas entre múltiplas threads ou processos pode reduzir o tempo total de execução e analisa os fatores que influenciam o *speedup* e a eficiência do paralelismo.

Foram realizados dois experimentos principais:

*   **Experimento E1:** Comparação do tempo de execução das três versões (sequencial, threads e processos) para matrizes de dimensões crescentes.
*   **Experimento E2:** Análise do impacto do número de unidades de processamento paralelas (P) no desempenho das versões com threads e processos.

Os programas foram desenvolvidos em C++, e os resultados foram coletados, analisados e visualizados através de scripts de automação e análise de dados.

## 2. Implementação

O projeto foi estruturado em quatro programas principais em C++, compilados com `g++` e otimização `-O2` para garantir uma medição de desempenho justa.

### 2.1. Gerador de Matrizes (`gerador_matrizes.cpp`)

Este programa auxiliar é responsável por criar as matrizes de entrada para os testes. Ele gera duas matrizes quadradas de uma dimensão especificada via linha de comando, preenchidas com números de ponto flutuante aleatórios (entre 1.0 e 100.0). As matrizes são salvas em arquivos de texto (`matriz_a_<dim>.txt` e `matriz_b_<dim>.txt`), com a dimensão na primeira linha, facilitando o carregamento pelos outros programas.

### 2.2. Multiplicação Sequencial (`multiplicacao_sequencial.cpp`)

A implementação sequencial utiliza o algoritmo clássico de multiplicação de matrizes, com três laços aninhados. O programa carrega as duas matrizes de entrada, realiza a multiplicação, mede o tempo de execução da operação e salva a matriz resultante em um arquivo.

### 2.3. Multiplicação Paralela com Threads (`multiplicacao_threads.cpp`)

Esta versão paraleliza o cálculo utilizando a biblioteca `<thread>` do C++. A matriz de resultado é dividida horizontalmente, e cada thread fica responsável por calcular um conjunto de linhas. A distribuição das linhas entre as threads é feita de forma a balancear a carga o máximo possível. Como as threads escrevem em posições distintas da matriz de resultado, não há necessidade de mecanismos de exclusão mútua (mutex) para proteger o acesso à memória compartilhada, evitando overhead de sincronização.

### 2.4. Multiplicação Paralela com Processos (`multiplicacao_processos.cpp`)

A paralelização com processos é implementada utilizando a chamada de sistema `fork()`. De forma similar à versão com threads, cada processo filho calcula uma faixa de linhas da matriz resultado. A principal diferença reside no mecanismo de compartilhamento de dados. Como processos não compartilham memória por padrão, foi utilizada a chamada `mmap()` para criar uma região de memória compartilhada onde a matriz resultado é armazenada. Após a conclusão de todos os processos filhos, o processo pai copia o resultado da memória compartilhada e o salva em arquivo.

## 3. Experimentos e Resultados

Os experimentos foram conduzidos em um ambiente controlado para garantir a consistência dos resultados. Antes da coleta de dados, foi executado um script de verificação (`verificar_corretude.sh`) que confirmou que todas as implementações produzem resultados numericamente idênticos.

### 3.1. Experimento E1: Sequencial vs. Paralelo

Neste experimento, comparamos o tempo de execução das três implementações para matrizes de tamanho 100x100, 200x200, 400x400, 800x800 e 1600x1600. As versões paralelas foram configuradas com P=4 (4 threads ou 4 processos).

![Gráfico do Experimento E1](grafico_experimento_e1.png)

**Tabela de Resultados (Tempo em ms):**

| Tamanho | Sequencial | Threads (P=4) | Processos (P=4) | Speedup Threads | Speedup Processos |
|:-------:|:----------:|:-------------:|:---------------:|:---------------:|:-----------------:|
| 100x100 | 1          | 0             | 1               | -               | 1.00x             |
| 200x200 | 9          | 2             | 4               | 4.50x           | 2.25x             |
| 400x400 | 93         | 24            | 42              | 3.88x           | 2.21x             |
| 800x800 | 754        | 193           | 245             | 3.91x           | 3.08x             |
| 1600x1600| 24462      | 5867          | 5565            | 4.17x           | 4.40x             |

**Análise do Experimento E1:**

*   **Escalabilidade:** O gráfico de tempo de execução (em escala logarítmica) mostra claramente que o tempo cresce de forma cúbica para todas as versões, como esperado. As versões paralelas são consistentemente mais rápidas que a sequencial, especialmente para matrizes maiores.
*   **Speedup:** O gráfico de speedup revela que, para P=4, o ganho de desempenho se aproxima do ideal (4x) à medida que o tamanho da matriz aumenta. Isso ocorre porque, em matrizes maiores, o tempo gasto com o cálculo (que é paralelizado) domina sobre o overhead de criação de threads/processos e gerenciamento de memória.
*   **Threads vs. Processos:** A versão com threads geralmente supera a versão com processos para matrizes menores e médias. Isso se deve ao menor custo de criação e comunicação entre threads, que compartilham o mesmo espaço de endereçamento. No entanto, para a maior matriz (1600x1600), a versão com processos se mostrou ligeiramente mais rápida, o que pode ser atribuído a fatores como o cache da CPU e a forma como o sistema operacional gerencia os processos.

### 3.2. Experimento E2: Impacto do Número de P

Este experimento avaliou como o desempenho das versões paralelas é afetado pelo número de threads/processos (P), utilizando uma matriz de tamanho fixo (800x800). Foram testados valores de P de 1, 2, 4, 6 e 8.

![Gráfico do Experimento E2](grafico_experimento_e2.png)

**Tabela de Resultados (Matriz 800x800, Tempo em ms):**

| P | Threads | Processos | Speedup Threads | Speedup Processos | Eficiência Threads | Eficiência Processos |
|:-:|:-------:|:---------:|:---------------:|:-----------------:|:------------------:|:--------------------:|
| 1 | 840     | 823       | 0.88x           | 0.90x             | 0.88               | 0.90                 |
| 2 | 387     | 381       | 1.92x           | 1.95x             | 0.96               | 0.98                 |
| 4 | 209     | 193       | 3.56x           | 3.85x             | 0.89               | 0.96                 |
| 6 | 222     | 206       | 3.35x           | 3.61x             | 0.56               | 0.60                 |
| 8 | 744     | 220       | 0.99x           | 3.38x             | 0.12               | 0.42                 |

**Análise do Experimento E2:**

*   **Valor Ideal de P:** O desempenho máximo para ambas as implementações (threads e processos) foi alcançado com **P=4**. O speedup começa a diminuir para P > 4. Isso sugere que o ambiente de execução possui 4 núcleos de processamento disponíveis. Ao usar mais de 4 threads/processos, o sistema operacional precisa gastar tempo com a troca de contexto entre eles, o que introduz um overhead que anula os ganhos do paralelismo.
*   **Lei de Amdahl:** Os resultados demonstram a Lei de Amdahl na prática. O speedup não é perfeitamente linear com o aumento de P, pois sempre há uma porção do código que não pode ser paralelizada (leitura de arquivos, criação das unidades paralelas, etc.).
*   **Degradação de Desempenho:** A degradação de desempenho é particularmente acentuada na versão com threads para P=8, onde o tempo de execução aumenta drasticamente. Isso pode ser causado por uma contenção excessiva de recursos ou pela forma como o escalonador do sistema operacional lida com um número de threads que excede o número de núcleos físicos.
*   **Eficiência:** A eficiência (Speedup/P) é mais alta para P=2 e P=4, indicando o melhor aproveitamento dos recursos de hardware. Para P > 4, a eficiência cai significativamente, mostrando que adicionar mais unidades de processamento não é vantajoso.

## 4. Conclusões

Este trabalho demonstrou com sucesso a eficácia da paralelização na otimização da multiplicação de matrizes. As conclusões principais são:

1.  **Paralelismo é Eficaz:** Tanto a paralelização com threads quanto com processos resultaram em ganhos de desempenho significativos em comparação com a abordagem sequencial, especialmente para problemas de grande escala.

2.  **Overhead é Relevante:** Para matrizes pequenas, o custo de criar e gerenciar threads/processos pode superar os benefícios do paralelismo. O speedup torna-se mais expressivo à medida que o tempo de computação aumenta.

3.  **O Valor Ideal de P é Crucial:** O número de unidades de processamento paralelas (P) deve, idealmente, corresponder ao número de núcleos de processamento disponíveis no hardware. Utilizar um valor de P superior a este número leva à degradação do desempenho devido ao overhead de troca de contexto. No ambiente testado, o valor ideal de P foi **4**.

4.  **Threads vs. Processos:** Para esta tarefa específica, a diferença de desempenho entre threads e processos não foi drasticamente grande, mas a implementação com threads tende a ser ligeiramente mais eficiente para um número menor de núcleos devido ao menor custo de criação e comunicação. A implementação com processos, embora um pouco mais complexa devido à necessidade de gerenciamento explícito de memória compartilhada, oferece um isolamento maior entre as unidades de trabalho.

Em suma, a escolha da estratégia de paralelização e a configuração correta dos seus parâmetros são fundamentais para extrair o máximo de desempenho do hardware disponível.
