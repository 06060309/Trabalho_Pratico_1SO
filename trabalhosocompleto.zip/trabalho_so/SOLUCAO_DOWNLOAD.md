# 🔧 Solução para Problema de Download

Se você está vendo o erro `Cannot open: No such file or directory`, aqui estão **3 soluções** para resolver:

---

## 🎯 Solução 1: Download Individual dos Arquivos (RECOMENDADA)

### Passo 1: Criar Diretório
```bash
mkdir trabalho_so
cd trabalho_so
```

### Passo 2: Baixar Arquivos Principais
Baixe os seguintes arquivos dos anexos da conversa e coloque na pasta `trabalho_so`:

**Arquivos Essenciais (.cpp):**
- `gerador_matrizes.cpp`
- `multiplicacao_sequencial.cpp`
- `multiplicacao_threads.cpp`
- `multiplicacao_processos.cpp`

**Scripts (.sh):**
- `experimento_e1.sh`
- `experimento_e2_rapido.sh`
- `verificar_corretude.sh`
- `instalar_sem_tar.sh`

**Análise (.py):**
- `analisar_resultados.py`

**Documentação (.md):**
- `README.md`
- `relatorio.md`
- `Makefile`

### Passo 3: Executar Instalação
```bash
chmod +x *.sh
./instalar_sem_tar.sh
```

---

## 🔄 Solução 2: Recriar Arquivo TAR

Se você tem acesso aos arquivos individuais:

```bash
# Criar diretório
mkdir trabalho_so
cd trabalho_so

# Copiar todos os arquivos para esta pasta
# (baixar dos anexos da conversa)

# Criar arquivo tar
cd ..
tar -czf trabalho_so_completo.tar.gz trabalho_so/

# Agora extrair normalmente
tar -xzf trabalho_so_completo.tar.gz
```

---

## 📁 Solução 3: Criação Manual Completa

### Criar estrutura básica:
```bash
mkdir trabalho_so
cd trabalho_so
```

### Criar arquivos principais:

#### 1. gerador_matrizes.cpp
```cpp
#include <iostream>
#include <fstream>
#include <random>
#include <iomanip>
#include <chrono>

using namespace std;

void gerarMatriz(const string& nomeArquivo, int dimensao) {
    ofstream arquivo(nomeArquivo);
    
    if (!arquivo.is_open()) {
        cerr << "Erro ao criar arquivo: " << nomeArquivo << endl;
        exit(1);
    }
    
    random_device rd;
    mt19937 gen(rd());
    uniform_real_distribution<double> dis(1.0, 100.0);
    
    arquivo << dimensao << endl;
    
    for (int i = 0; i < dimensao; i++) {
        for (int j = 0; j < dimensao; j++) {
            arquivo << fixed << setprecision(2) << dis(gen);
            if (j < dimensao - 1) {
                arquivo << " ";
            }
        }
        arquivo << endl;
    }
    
    arquivo.close();
    cout << "Matriz " << dimensao << "x" << dimensao << " salva em: " << nomeArquivo << endl;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cout << "Uso: " << argv[0] << " <dimensao>" << endl;
        return 1;
    }
    
    int dimensao = atoi(argv[1]);
    
    if (dimensao <= 0) {
        cerr << "Erro: A dimensão deve ser um número positivo." << endl;
        return 1;
    }
    
    cout << "Gerando matrizes " << dimensao << "x" << dimensao << "..." << endl;
    
    auto inicio = chrono::high_resolution_clock::now();
    
    string arquivoA = "matriz_a_" + to_string(dimensao) + ".txt";
    gerarMatriz(arquivoA, dimensao);
    
    string arquivoB = "matriz_b_" + to_string(dimensao) + ".txt";
    gerarMatriz(arquivoB, dimensao);
    
    auto fim = chrono::high_resolution_clock::now();
    auto duracao = chrono::duration_cast<chrono::milliseconds>(fim - inicio);
    
    cout << "Matrizes geradas com sucesso em " << duracao.count() << " ms" << endl;
    
    return 0;
}
```

#### 2. Compilar e testar:
```bash
g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11
./gerador_matrizes 10
```

**💡 Para os outros arquivos, baixe dos anexos da conversa - é mais rápido e confiável!**

---

## 🚀 Execução Rápida (Após Resolver Download)

```bash
# Método 1: Com arquivo tar (se conseguir baixar)
tar -xzf trabalho_so_completo.tar.gz
cd trabalho_so
./instalar.sh

# Método 2: Com arquivos individuais
mkdir trabalho_so
cd trabalho_so
# (baixar arquivos dos anexos)
./instalar_sem_tar.sh

# Método 3: Usando make (se tiver Makefile)
make all
make test
make experimentos
```

---

## 🔍 Verificar se Funcionou

```bash
# Verificar arquivos
ls -la *.cpp *.sh *.py

# Compilar tudo
g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11
g++ -o multiplicacao_sequencial multiplicacao_sequencial.cpp -std=c++11 -O2
g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2
g++ -o multiplicacao_processos multiplicacao_processos.cpp -std=c++11 -O2

# Teste rápido
./gerador_matrizes 5
./multiplicacao_sequencial 5
./multiplicacao_threads 5 2
./multiplicacao_processos 5 2
```

---

## 📱 Para Windows (WSL)

```powershell
# No PowerShell
wsl

# No WSL, seguir uma das soluções acima
mkdir trabalho_so
cd trabalho_so
# Baixar arquivos...
chmod +x *.sh
./instalar_sem_tar.sh
```

---

## 🆘 Se Nada Funcionar

### Opção A: Criar projeto mínimo
```bash
mkdir trabalho_so_minimo
cd trabalho_so_minimo

# Criar apenas o gerador (código acima)
# Criar multiplicação sequencial básica
# Testar funcionamento básico
```

### Opção B: Usar Docker
```bash
docker run -it ubuntu:22.04
apt update && apt install -y build-essential
# Criar arquivos manualmente
```

### Opção C: Pedir ajuda
- Verifique se todos os arquivos foram baixados corretamente
- Confirme que está no diretório correto
- Verifique permissões dos arquivos

---

## ✅ Lista de Verificação

- [ ] Diretório `trabalho_so` criado
- [ ] Arquivos `.cpp` baixados
- [ ] Scripts `.sh` baixados  
- [ ] Arquivo `analisar_resultados.py` baixado
- [ ] Permissões executáveis configuradas (`chmod +x *.sh`)
- [ ] Dependências instaladas (g++, python3, pip3)
- [ ] Teste de compilação funcionando

**Após completar a lista, execute `./instalar_sem_tar.sh` e tudo deve funcionar! 🎉**
