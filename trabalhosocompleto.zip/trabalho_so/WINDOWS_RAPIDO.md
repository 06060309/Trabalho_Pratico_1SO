# ⚡ Execução Rápida no Windows

## 🎯 Método Mais Simples (5 minutos)

### 1. Instalar WSL2 (uma vez só)
```powershell
# Abrir PowerShell como Administrador
wsl --install -d Ubuntu

# Reiniciar o computador
```

### 2. Executar Projeto
```batch
# Duplo clique no arquivo:
executar_windows.bat
```

**OU** no PowerShell:
```powershell
.\executar_windows.ps1
```

---

## 🚀 Passo a Passo Detalhado

### Passo 1: Preparar Windows
1. **Pressione** `Win + X`
2. **Clique** em "Windows PowerShell (Admin)"
3. **Digite**: `wsl --install -d Ubuntu`
4. **Reinicie** o computador

### Passo 2: Configurar Ubuntu (primeira vez)
1. **Abra** o Ubuntu (aparecerá automaticamente)
2. **Crie** um nome de usuário
3. **Crie** uma senha
4. **Aguarde** a instalação

### Passo 3: Executar Projeto
1. **Baixe** o arquivo `trabalho_so_completo.tar.gz`
2. **Coloque** na mesma pasta dos scripts
3. **Duplo clique** em `executar_windows.bat`
4. **Aguarde** a execução (5-10 minutos)

### Passo 4: Ver Resultados
- Os resultados aparecerão na pasta `resultados`
- A pasta abrirá automaticamente

---

## 📁 Estrutura de Arquivos

```
📁 Sua pasta/
├── 📄 trabalho_so_completo.tar.gz  (baixado)
├── 📄 executar_windows.bat         (duplo clique)
├── 📄 executar_windows.ps1         (alternativa)
└── 📁 resultados/                  (criado automaticamente)
    ├── 🖼️ grafico_experimento_e1.png
    ├── 🖼️ grafico_experimento_e2.png
    ├── 📊 resultados_e1.csv
    ├── 📊 resultados_e2.csv
    ├── 📄 relatorio.md
    └── 📄 README.md
```

---

## 🔧 Se Algo Der Errado

### Erro: "WSL não encontrado"
```powershell
# Como Administrador:
wsl --install -d Ubuntu
# Reiniciar PC
```

### Erro: "Arquivo não encontrado"
- Certifique-se de que `trabalho_so_completo.tar.gz` está na mesma pasta

### Erro: "Ubuntu não configurado"
```powershell
# Abrir Ubuntu e configurar usuário/senha
wsl
```

### Erro: "Permission denied"
```powershell
# Executar como Administrador
```

---

## 💡 Comandos Úteis

### Verificar se WSL funciona:
```powershell
wsl --version
wsl bash -c "echo 'Funcionando!'"
```

### Executar manualmente:
```powershell
# Copiar arquivo
wsl cp trabalho_so_completo.tar.gz ~/

# Extrair e executar
wsl bash -c "cd ~ && tar -xzf trabalho_so_completo.tar.gz && cd trabalho_so && ./instalar.sh && make experimentos"

# Copiar resultados
wsl cp ~/trabalho_so/*.png ./
wsl cp ~/trabalho_so/*.csv ./
wsl cp ~/trabalho_so/*.md ./
```

### Acessar arquivos do WSL:
```
\\wsl$\Ubuntu\home\username\trabalho_so\
```

---

## 🎮 Execução Super Rápida

**Para quem já tem WSL instalado:**

1. **Baixar** `trabalho_so_completo.tar.gz`
2. **Duplo clique** em `executar_windows.bat`
3. **Aguardar** 5-10 minutos
4. **Pronto!** Resultados na pasta `resultados`

---

## 📊 O Que Você Vai Obter

✅ **Gráficos profissionais** comparando desempenho
✅ **Dados em CSV** para análise
✅ **Relatório completo** em Markdown
✅ **Código fonte** funcionando
✅ **Speedup de até 4.4x** demonstrado

---

## 🏆 Resultado Final

Após 5-10 minutos você terá:
- **Análise completa** de paralelização
- **Gráficos comparativos** threads vs processos
- **Dados de performance** detalhados
- **Relatório técnico** pronto para entrega

**Tudo funcionando perfeitamente no Windows! 🎉**
