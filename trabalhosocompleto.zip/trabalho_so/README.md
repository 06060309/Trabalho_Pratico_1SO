# Trabalho Prático 1 - Sistemas Operacionais
## Multiplicação de Matrizes: Sequencial vs. Paralelo

Este projeto implementa e compara três abordagens para multiplicação de matrizes:
- **Sequencial**: Implementação tradicional com um único thread
- **Threads**: Paralelização usando threads POSIX
- **Processos**: Paralelização usando processos com memória compartilhada

---

## 📁 Estrutura do Projeto

```
trabalho_so/
├── gerador_matrizes.cpp          # Programa auxiliar para gerar matrizes
├── multiplicacao_sequencial.cpp  # Implementação sequencial
├── multiplicacao_threads.cpp     # Implementação com threads
├── multiplicacao_processos.cpp   # Implementação com processos
├── experimento_e1.sh            # Script do Experimento E1
├── experimento_e2_rapido.sh     # Script do Experimento E2
├── verificar_corretude.sh       # Script de verificação
├── analisar_resultados.py       # Script de análise e gráficos
├── relatorio.md                 # Relatório completo
└── README.md                    # Este arquivo
```

---

## 🛠️ Compilação

Para compilar todos os programas:

```bash
# Compilar gerador de matrizes
g++ -o gerador_matrizes gerador_matrizes.cpp -std=c++11

# Compilar versão sequencial
g++ -o multiplicacao_sequencial multiplicacao_sequencial.cpp -std=c++11 -O2

# Compilar versão com threads
g++ -o multiplicacao_threads multiplicacao_threads.cpp -std=c++11 -pthread -O2

# Compilar versão com processos
g++ -o multiplicacao_processos multiplicacao_processos.cpp -std=c++11 -O2
```

---

## 🚀 Uso dos Programas

### 1. Gerador de Matrizes
```bash
./gerador_matrizes <dimensao>
```
**Exemplo:**
```bash
./gerador_matrizes 100
```
Gera `matriz_a_100.txt` e `matriz_b_100.txt`

### 2. Multiplicação Sequencial
```bash
./multiplicacao_sequencial <dimensao>
```
**Exemplo:**
```bash
./multiplicacao_sequencial 100
```
Gera `resultado_sequencial_100.txt`

### 3. Multiplicação com Threads
```bash
./multiplicacao_threads <dimensao> <num_threads>
```
**Exemplo:**
```bash
./multiplicacao_threads 100 4
```
Gera `resultado_threads_100_4.txt`

### 4. Multiplicação com Processos
```bash
./multiplicacao_processos <dimensao> <num_processos>
```
**Exemplo:**
```bash
./multiplicacao_processos 100 4
```
Gera `resultado_processos_100_4.txt`

---

## 🧪 Executando os Experimentos

### Verificação de Corretude
Antes de executar os experimentos, verifique se todos os programas produzem resultados idênticos:
```bash
./verificar_corretude.sh
```

### Experimento E1: Sequencial vs. Paralelo
Compara o desempenho das três versões para diferentes tamanhos de matriz:
```bash
./experimento_e1.sh
```
**Saída:** `resultados_e1.csv`

### Experimento E2: Impacto do Número de P
Analisa como o número de threads/processos afeta o desempenho:
```bash
./experimento_e2_rapido.sh
```
**Saída:** `resultados_e2.csv`

### Análise e Gráficos
Para gerar gráficos e análises dos resultados:
```bash
python3 analisar_resultados.py
```
**Saídas:**
- `grafico_experimento_e1.png`
- `grafico_experimento_e2.png`

---

## 📊 Resultados Principais

### Experimento E1
- **Speedup máximo:** ~4.4x para matriz 1600x1600 com processos
- **Melhor desempenho:** Threads para matrizes pequenas/médias, processos para matrizes grandes
- **Escalabilidade:** Speedup aumenta com o tamanho da matriz

### Experimento E2
- **P ideal:** 4 (tanto para threads quanto processos)
- **Eficiência máxima:** P=2 (0.96-0.98)
- **Degradação:** P > 4 causa perda de desempenho devido ao overhead

---

## 📋 Dependências

### Sistema Operacional
- Linux (testado no Ubuntu 22.04)

### Compilador
- g++ com suporte a C++11
- Biblioteca pthread

### Python (para análise)
- Python 3.x
- pandas
- matplotlib
- seaborn
- numpy

### Instalação das dependências Python:
```bash
pip3 install pandas matplotlib seaborn numpy
```

---

## 🔍 Detalhes Técnicos

### Algoritmo de Multiplicação
- Complexidade: O(n³)
- Algoritmo clássico com três laços aninhados

### Paralelização
- **Threads:** Divisão horizontal da matriz resultado
- **Processos:** Memória compartilhada via mmap()
- **Balanceamento:** Distribuição equitativa de linhas

### Medição de Tempo
- `std::chrono::high_resolution_clock`
- Medição apenas da operação de multiplicação
- Exclusão do tempo de I/O

---

## 📈 Interpretação dos Resultados

### Speedup
```
Speedup = Tempo_Sequencial / Tempo_Paralelo
```

### Eficiência
```
Eficiência = Speedup / Número_de_P
```

### Valores Ideais
- **Speedup ideal:** Igual ao número de núcleos
- **Eficiência ideal:** 1.0 (100%)

---

## 🎯 Conclusões

1. **Paralelismo é eficaz** para problemas computacionalmente intensivos
2. **P ideal = número de núcleos** do processador
3. **Overhead** é significativo para problemas pequenos
4. **Threads vs. Processos:** Performance similar, threads ligeiramente mais eficientes

---

## 📝 Relatório Completo

Para análise detalhada, consulte o arquivo `relatorio.md` que contém:
- Metodologia completa
- Análise aprofundada dos resultados
- Gráficos e tabelas
- Discussões teóricas
- Conclusões e recomendações
